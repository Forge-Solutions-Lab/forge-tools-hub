# 📑 Project Handoff & Technical Architecture Document
**Project Name**: Nihongo Quest Exam Trainer (JN60101 Japanese for Communication 1 — PIM)  
**Date**: September 21, 2026  
**Repository**: `git@github.com:Phongdaani08/Nihongo-Quest-Exam-Trainer.git` (Branch: `main`)  
**Production URL**: [https://nihongo-quest-exam-trainer.vercel.app](https://nihongo-quest-exam-trainer.vercel.app)  
**Location in Workspace**: `/Users/phongdanaisomphan/Projects/Nihongo Quest Exam Trainer/skills-agent/docs/handoff/HANDOFF.md`

---

## 🎯 1. Executive Summary

**Nihongo Quest Exam Trainer** is a specialized interactive web application engineered for Panyapiwat Institute of Management (PIM) students taking the **JN60101 Japanese for Communication 1 Midterm & Final Exams**. 

The system trains students across 3 core exam sections according to the exact PIM curriculum, combining gamified practice, real-time audio pronunciation, strict timer simulations, custom endless modes, and comprehensive performance analytics.

---

## 🏗️ 2. System Architecture & Component Map

```
frontend/
├── src/
│   ├── assets/
│   │   └── flags/                  # High-quality SVG Vector Flags
│   │       ├── flag_thailand.svg   # Thailand
│   │       ├── flag_japan.svg      # Japan
│   │       ├── flag_usa.svg        # United States
│   │       └── flag_china.svg      # China
│   ├── components/
│   │   ├── JikoShokaiTrainer.tsx    # Section 1: Self-Introduction Grammar Puzzle
│   │   ├── SpeedFlashArena.tsx      # Section 2: Fast Vocabulary Recall Arena
│   │   ├── VisualQAArena.tsx        # Section 3: Visual Q&A (5 Core Question Types)
│   │   ├── MockExamSimulator.tsx    # Timed 3-Min Mock Exam & Endless Practice Mode
│   │   ├── CustomPresetManagerModal.tsx # Preset Builder for Endless Mode (Filter Sec2 & Sec3)
│   │   └── AnalyticsDashboard.tsx   # ECharts Analytics, Mastery Rates & History
│   ├── services/
│   │   └── api.ts                   # Vocabulary Data Store (21 Chapter 1 items & dual-mode)
│   ├── utils/
│   │   └── speech.ts                # Web Speech API Audio Engine (ja-JP / th-TH)
│   ├── index.css                    # Design Tokens, Glassmorphism, Theme Variables
│   └── App.tsx                      # Root Application & Navigation Router
```

---

## 🧩 3. Core Modules Breakdown

### Section 1: Jiko Shōkai (自己紹介 — Self-Introduction Puzzle)
- **Target Points**: 5 Points (5 Sentences)
- **Files**:
  - `frontend/src/components/JikoShokaiTrainer.tsx` (Dedicated training arena)
  - `frontend/src/components/MockExamSimulator.tsx` (Exam integration)
- **5 Script Steps**:
  1. `Hajimemashite.` (คำทักทาย)
  2. `Watashi wa Poom desu.` (บอกชื่อ)
  3. `Panyapiwatto keiei daigaku no gakusei desu.` (สังกัดสถาบันการจัดการปัญญาภิวัฒน์)
  4. `Shumi wa [manga | dokusho | eiga] desu.` (งานอดิเรก)
  5. `Dōzo yoroshiku onegai itashimasu.` (ประโยคปิดท้าย)
- **Key Features**:
  - **Random Token Scrambler**: Word tokens in the bank are shuffled automatically at start/reset so they never reveal the answer order.
  - **Hybrid Interaction**: Supports both **Drag & Drop** (`draggable={true}`, drop target highlights) and **Click-to-Select**. Clicking assembled tokens removes them.
  - **Error Prevention & Immediate Audio**: Instant phonetic Japanese pronunciation upon completion.

---

### Section 2: Speed Flash Translation (แปลความหมายคำศัพท์)
- **Target Points**: 10 Points (10 Questions in 3-minute exam / Infinite in Endless)
- **Files**:
  - `frontend/src/components/SpeedFlashArena.tsx`
  - `frontend/src/components/MockExamSimulator.tsx`
- **Data & Dual-Mode**:
  - 21 Chapter 1 vocabulary items with full Romaji, Hiragana/Katakana, Thai translations, and audio.
  - Dual-mode support: Text-only translation vs. Visual object recognition.

---

### Section 3: Visual Q&A Arena (ถาม-ตอบจากรูปภาพตามหลักไวยากรณ์)
- **Target Points**: 5 Points (5 Structured Questions in 3-minute exam)
- **Files**:
  - `frontend/src/components/VisualQAArena.tsx`
  - `frontend/src/components/MockExamSimulator.tsx`
- **5 Strict Question Types (Sequenced strictly in 3-min Timed Exam)**:
  1. **Type 1 (สิ่งของ - Objects)**:
     - Question: `Kore wa nan desu ka.`
     - Answer: `Kore wa [isu | hon | tokei | kuruma | ...] desu.`
  2. **Type 2 (ประเทศต้นกำเนิด - 4 Countries)**:
     - Question: `Anohito wa doko kara kimashita ka.`
     - Answer: `Anohito wa [Nihon | Amerika | Chūgoku | Tai] kara kimashita.`
     - Assets: SVG Vector Flags (`flag_thailand.svg`, `flag_japan.svg`, `flag_usa.svg`, `flag_china.svg`).
  3. **Type 3 (บุคคลและอาชีพ - Occupations)**:
     - Question: `Anohito wa dare desu ka.`
     - Answer: `Anohito wa [ginkōin | kenkyūsha | sensei | gakusei | ...] desu.`
  4. **Type 4 (ประเภทนิตยสาร/หนังสือ - Magazine Types)**:
     - Question: `Kore wa nan no hon/zasshi desu ka.`
     - Answer: `Kore wa [kuruma | kamera | nihongo | ...] no hon/zasshi desu.`
  5. **Type 5 (สถานที่/ประโยคสำคัญ - Places & Phrases)**:
     - Question: `Koko wa doko desu ka.` / `O-kuni wa doko desu ka.`
     - Answer: `Koko wa [daigaku | kyōshitsu | ginkō] desu.`

---

### 4. Endless Practice & Custom Preset Engine
- **Files**:
  - `frontend/src/components/CustomPresetManagerModal.tsx`
- **Capabilities**:
  - Filter specific Question Types (1 to 5) in Section 3.
  - Pick custom vocabulary subsets for Section 2.
  - Instant vs. Hidden Choice reveal modes (Flashcard recall mode).
  - Saved directly to browser `localStorage`.

---

## 🛠️ 4. Build, Test & Deployment Guide

### Local Development
```bash
# Navigate to frontend
cd frontend

# Install dependencies
npm install

# Run local Vite dev server (http://localhost:5173)
npm run dev
```

### Production Build & Verification
```bash
# Typecheck & Vite Production Build
npm run build
```

### Git & Vercel Deployment
The repository is hooked to Vercel for automatic continuous deployment upon pushing to `main`:
```bash
git add .
git commit -m "feat: <description>"
git push origin main
```

---

## 📋 5. Recent Changelog (Session Summary)

| Timestamp | Scope | Summary of Changes |
|---|---|---|
| **2026-09-21** | Section 1 | Added random token scrambler & HTML5 Drag-and-Drop alongside click-to-select in `JikoShokaiTrainer` and `MockExamSimulator`. |
| **2026-09-21** | Section 3 | Enforced strict 5-Pattern Question Sequencing (Type 1-5) for Timed 3-Min Exam. |
| **2026-09-21** | Endless Mode | Added quick Question Pattern selector filter buttons for Visual Q&A endless training. |
| **2026-09-20** | Vocabulary | Added `kenkyūsha` (researcher), 4 country flags (SVG vectors), and Chapter 1 full 21 vocab items. |
| **2026-09-20** | UI/UX | Dark-mode glassmorphism, responsive mobile buttons, ECharts analytics dashboard. |

---

## 🚀 6. Future Roadmap Recommendations

1. **Chapter 2 & 3 Expansion**: Add Chapter 2 & 3 vocabulary and particle grammar (`koko/soko/asoko`, `kore/sore/are`, prices `ikura`).
2. **Speech Recognition (STT)**: Integrate browser Speech-to-Text (`webkitSpeechRecognition`) for oral exam recitation simulation.
3. **PIM Exam Timer Countdown Sound**: Add subtle audio cues during the last 30 seconds of the 3-minute exam.
